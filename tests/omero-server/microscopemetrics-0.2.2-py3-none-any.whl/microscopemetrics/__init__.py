class SaturationError(Exception):
    pass


class FittingError(Exception):
    pass
